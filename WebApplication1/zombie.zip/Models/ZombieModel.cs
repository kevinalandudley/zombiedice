﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class ZombieModel
    {
        //public crap crap { get; set; }
        public virtual Turn turn { get; set; }
        //private Turn _turn;
        //public DieCollection hand;
        //public Turn turn
        //{
        //    get
        //    {
        //        if (_turn == null)
        //        {
        //            _turn = new Turn();
        //            _turn.hand.dice = new List<Die>();
        //            _turn.keep.dice = new List<Die>();

        //            _turn.hand.dice.Add(new Die(DieKind.Green));

        //            _turn.hand.dice.Add(new Die(DieKind.Hottie));

        //            _turn.hand.dice.Add(new Die(DieKind.Hunk));

        //            _turn.hand.dice.Add(new Die(DieKind.Red));

        //            _turn.hand.dice.Add(new Die(DieKind.Santa));

        //            _turn.hand.dice.Add(new Die(DieKind.Yellow));
        //        }
        //        return _turn;
        //    }
        //    set
        //    {
        //        _turn = value;
        //    }
        //}


    }
}