﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Turn
    {
        public DieCollection cup { get; set; }

        //public List<Die> dice { get; set; }

        public DieCollection hand { get; set; }// = new DieCollection();

        public DieCollection keep { get; set; }// = new DieCollection();

        public void SortUnresolvedDice()
        {
            //var removeDice = dice;
            var newHand = hand;
            //for (int d = 0; d<dice.Count; d++)
            //{
            //    if(dice[d].FaceType != DieFaceType.Footprints)
            //    {
            //        keep.dice.Add(dice[d]);
            //        hand.dice.Remove(die);
            //    }
            //}
            foreach (var die in hand.dice.ToList())
            {
                if (die.FaceType != DieFaceType.Footprints)
                {
                    keep.dice.Add(die);

                    hand.dice.Remove(die);
                }
            }
            hand.dice = newHand.dice;
        }
    }
}