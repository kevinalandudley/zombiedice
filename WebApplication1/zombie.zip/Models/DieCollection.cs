﻿using System;
using System.Collections.Generic;


namespace WebApplication1.Models
{
    public class DieCollection
    {

        public List<Die> dice { get; set; }

    }
}