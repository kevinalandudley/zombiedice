﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class JunkController : Controller
    {
        // GET: Junk
        public ActionResult Index()
        {
            var model = new JunkModel();
            model.Number = 1;
            return View(model);
        }

        [HttpPost]
        public ActionResult Add(JunkModel model)
        {
            model.Number += 1;
            return View("Index", model);
        }
    }
}