﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ZombieController : Controller
    {
        // GET: Zombie
        public ActionResult Index()
        {
            var model = new ZombieModel();
            model.turn = new Turn();
            model.turn.hand = new DieCollection();
            model.turn.keep = new DieCollection();
            model.turn.hand.dice = new List<Die>();
            model.turn.keep.dice = new List<Die>();

            model.turn.hand.dice.Add(new Die(DieKind.Green));
            model.turn.hand.dice.Add(new Die(DieKind.Hottie));
            model.turn.hand.dice.Add(new Die(DieKind.Hunk));
            model.turn.hand.dice.Add(new Die(DieKind.Red));
            model.turn.hand.dice.Add(new Die(DieKind.Santa));
            model.turn.hand.dice.Add(new Die(DieKind.Yellow));


            //model.turn.hand.dice.Add(new Die { kind = DieKind.Hottie });

            //model.turn.hand.dice.Add(new Die { kind = DieKind.Hunk });

            //model.turn.hand.dice.Add(new Die { kind = DieKind.Red });

            //model.turn.hand.dice.Add(new Die { kind = DieKind.Santa });

            //model.turn.hand.dice.Add(new Die {kind=  DieKind.Yellow});
            //model.crap = new crap();
            //model.crap.stuff = new List<crapliststuff>();
            //model.crap.stuff.Add(new crapliststuff { id = 123, jazz = new List<string> { "test", "bob" } });
            //model.crap.stuff.Add(new crapliststuff { id = 456, jazz = new List<string> { "ummm", "errr" } });

            return View(model);
        }

        [HttpPost]
        public ActionResult Roll(ZombieModel model)//, string command)//[Bind(Prefix = "ZombieModel")]
        {
            if (null == model.turn.keep)
            {
                model.turn.keep = new DieCollection();
                model.turn.keep.dice = new List<Die>();
            }

            //if (command == "Roll Dice")
            //{
                foreach (var die in model.turn.hand.dice)
                {
                    die.Roll();

                }
            //}

            //if (command == "Sort")
            //{
            //    model.turn.SortUnresolvedDice();
            //}


            return View("Index",model);
        }
    }
}
