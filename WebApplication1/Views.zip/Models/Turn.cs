﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Turn
    {
        public DieCollection cup { get; set; }

        public DieCollection hand = new DieCollection();

        public DieCollection keep = new DieCollection();

        public void SortUnresolvedDice(List<Die> dice)
        {
            foreach (var die in dice.ToList<Die>())
            {
                if (die.FaceType != DieFaceType.Footprints)
                {
                    keep.dice.Add(die);
                    hand.dice.Remove(die);
                }
            }
        }
    }
}